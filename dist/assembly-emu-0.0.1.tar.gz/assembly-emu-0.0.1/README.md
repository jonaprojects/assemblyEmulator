# Welcome to Emu++

## Installation
You can install Emu++ by running the following command in the terminal:
```bash
pip install emuplusplus
```

## Usage

