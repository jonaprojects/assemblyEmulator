# __init__.py

# Version of the emulator
__version__ = "1.0.1"